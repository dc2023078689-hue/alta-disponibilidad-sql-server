#!/usr/bin/env python3
"""Deterministic policy model; NOT a Windows/SQL Server simulator or availability measurement."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Case:
    primary_down: bool
    secondary_online: bool
    secondary_synchronized: bool
    quorum_available: bool
    automatic_enabled: bool

def automatic_failover_allowed(c):
    return all((c.primary_down, c.secondary_online, c.secondary_synchronized,
                c.quorum_available, c.automatic_enabled))

cases = {
    'S1_fail_primary_synced_quorum': (Case(True,True,True,True,True),True),
    'S2_secondary_not_synchronized': (Case(True,True,False,True,True),False),
    'S3_quorum_lost': (Case(True,True,True,False,True),False),
    'S4_manual_policy': (Case(True,True,True,True,False),False),
    'S5_primary_healthy': (Case(False,True,True,True,True),False),
}
if __name__ == '__main__':
    for name,(case,expected) in cases.items():
        got=automatic_failover_allowed(case)
        assert got == expected, name
        print('PASS: '+name+' => '+('ALLOW' if got else 'BLOCK'))
    print('SUMMARY: 5 of 5 logical policy cases passed. Not evidence of real availability or RTO.')
