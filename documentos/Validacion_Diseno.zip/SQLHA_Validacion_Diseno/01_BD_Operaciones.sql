/* Academic initialization. Run in SQL Server 2022 on the primary instance.
   An administrator must prepare backup directories and AG configuration separately. */
USE master;
GO
IF DB_ID(N'BD_Operaciones') IS NULL CREATE DATABASE BD_Operaciones;
GO
ALTER DATABASE BD_Operaciones SET RECOVERY FULL;
GO
USE BD_Operaciones;
GO
IF OBJECT_ID(N'dbo.RegistroPrueba',N'U') IS NULL
BEGIN
  CREATE TABLE dbo.RegistroPrueba(
    Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Lote UNIQUEIDENTIFIER NOT NULL,
    MarcaTiempo DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
    ValorPrueba INT NOT NULL CHECK (ValorPrueba > 0)
  );
END;
GO
DECLARE @lote UNIQUEIDENTIFIER = NEWID(), @i INT=1;
WHILE @i<=100
BEGIN
  INSERT INTO dbo.RegistroPrueba(Lote,ValorPrueba) VALUES (@lote,@i);
  SET @i+=1;
END;
SELECT Lote,COUNT(*) AS Registros,MIN(Id) AS Desde,MAX(Id) AS Hasta
FROM dbo.RegistroPrueba GROUP BY Lote ORDER BY Hasta DESC;
GO
