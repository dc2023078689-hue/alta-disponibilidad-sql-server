/* Read-only diagnostics: run after the group AG_CRITICA exists. */
SELECT ag.name AS Grupo, ar.replica_server_name AS Replica,
       ars.role_desc AS Rol, ars.connected_state_desc AS Conexion,
       ars.synchronization_health_desc AS Salud
FROM sys.availability_groups AS ag
JOIN sys.availability_replicas AS ar ON ag.group_id=ar.group_id
JOIN sys.dm_hadr_availability_replica_states AS ars ON ar.replica_id=ars.replica_id
WHERE ag.name=N'AG_CRITICA';
GO
SELECT DB_NAME(drs.database_id) AS BaseDatos, ar.replica_server_name,
       drs.synchronization_state_desc AS Sincronizacion,
       drs.synchronization_health_desc AS Salud,
       drs.log_send_queue_size AS ColaEnvioKB,
       drs.redo_queue_size AS ColaRedoKB
FROM sys.dm_hadr_database_replica_states AS drs
JOIN sys.availability_replicas AS ar ON drs.replica_id=ar.replica_id;
GO
