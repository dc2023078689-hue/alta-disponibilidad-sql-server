# Material reproducible para el diseno SQLHA

Este paquete no es un clúster de alta disponibilidad ejecutado. Contiene:

- `validar_diseno.py`: verificaciones estaticas reales de direccionamiento, duplicados, recursos y subredes.
- `simular_reglas_failover.py`: modelo LOGICO de elegibilidad de conmutacion segun condiciones necesarias. No mide SQL Server, Windows, tiempo de recuperacion ni perdida de transacciones.
- `01_BD_Operaciones.sql`: base de prueba con identificadores para ejecutar en una instancia SQL Server autorizada.
- `02_Diagnostico_AG.sql`: consultas para usar tras configurar AG_CRITICA. No inicia ni modifica el clúster.

Ejecutar `python validar_diseno.py` y `python simular_reglas_failover.py`.

Para Unidad III se requieren capturas reales, logs de WSFC, capturas de SSMS, y mediciones T0/T1 del cliente. Ningun resultado sintetico debe presentarse como ejecucion real de SQL Server.
