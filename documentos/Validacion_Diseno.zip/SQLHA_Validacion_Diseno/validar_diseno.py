#!/usr/bin/env python3
"""Static validation for SQLHA academic design. Does not access SQL Server."""
from ipaddress import ip_network, ip_address
from itertools import combinations

networks = {
    'clientes': ip_network('192.168.10.0/24'),
    'servidores': ip_network('192.168.20.0/24'),
    'administracion': ip_network('192.168.30.0/24'),
    'replicacion': ip_network('192.168.40.0/24'),
}
addresses = {
    'CLIENTE-01': ('192.168.10.10', 'clientes'),
    'RTR-CLI': ('192.168.10.1', 'clientes'),
    'DC-SRV01': ('192.168.20.10', 'servidores'),
    'SQL-SRV01': ('192.168.20.21', 'servidores'),
    'SQL-SRV02': ('192.168.20.22', 'servidores'),
    'CL-SQLHA': ('192.168.20.30', 'servidores'),
    'LST-SQLHA': ('192.168.20.40', 'servidores'),
    'RTR-SRV': ('192.168.20.1', 'servidores'),
    'ADMIN-01': ('192.168.30.10', 'administracion'),
    'RTR-ADM': ('192.168.30.1', 'administracion'),
    'SQL01-REP': ('192.168.40.21', 'replicacion'),
    'SQL02-REP': ('192.168.40.22', 'replicacion'),
}

def check(label, condition):
    if not condition:
        raise AssertionError('FAIL: '+label)
    print('PASS: '+label)

if __name__ == '__main__':
    check('four distinct RFC1918 subnets', all(n.is_private for n in networks.values()) and all(not a.overlaps(b) for a,b in combinations(networks.values(),2)))
    check('all assigned IPs belong to their declared subnet', all(ip_address(ip) in networks[seg] for ip,seg in addresses.values()))
    ip_list = [ip for ip,_ in addresses.values()]
    check('no duplicate IP assignments', len(ip_list) == len(set(ip_list)))
    check('cluster IP differs from listener and SQL node IPs', len(set(addresses[n][0] for n in ['SQL-SRV01','SQL-SRV02','CL-SQLHA','LST-SQLHA'])) == 4)
    check('router has interfaces on client, server and admin subnets', all(addresses[n][1] == seg for n,seg in [('RTR-CLI','clientes'),('RTR-SRV','servidores'),('RTR-ADM','administracion')]))
    allocated_gb = {'DC':2,'SQL1':5,'SQL2':5,'ROUTER':1}
    check('planned VM RAM total is 13 GB', sum(allocated_gb.values()) == 13)
    check('planned host leaves 7 GB before hypervisor overhead', 20 - sum(allocated_gb.values()) == 7)
    print('SUMMARY: 7 of 7 static design checks passed. No SQL Server/WSFC execution performed.')
